const Discord = require('discord.js');
const bot = new Discord.Client();

const token = 'NjU2OTQ2OTY0ODIyMzYwMDY1.XfqDmg.oyzwob2MfZhV6Zpz5WIHtdtV8C4';

const config = require("./config.json");
var request = require('request');
var mcPort = 25565;

bot.on('ready', () => {
    console.log('PatBot is active!')
    bot.user.setActivity('?help', { type: 'LISTENING' });

})

bot.on('message', message=>{
    if(message.content.indexOf(config.prefix) !== 0) return;
    const args = message.content.toLowerCase().slice(config.prefix.length).trim().split(/ +/g);
    if(message.author.bot) return;
    if(message.channel.type == 'dm') return;
    switch(args[0]){
        case "build":
            var aboutBuild = new Discord.RichEmbed()
            .setTitle('Build Information')
            .addField('Current Build:', 'pre-alpha v0.5')
            .addField('Current Patch', 'Patch A3')
            .setImage('https://i.imgur.com/tVsAOeR.png')
            .addField('Guilds:', bot.guilds.size)
            .setColor(0xebcf34)
            .setTimestamp()
            .setFooter('PatBot pre-alpha v0.5 by accurates#0001 😎', 'https://i.imgur.com/tVsAOeR.png');            
            message.channel.send(aboutBuild);
        break;
        case "help":
            const helpMenu = new Discord.RichEmbed()
            .setTitle('Help Menu')
            .addField('?build', 'Gives more info on the current build.')
            .addField('?help', 'Opens this menu')
            .addField('?insult', 'Feeling good? Time to ruin it for you!')
            .addField('?status', 'Checking status from a minecraft server, use ?help status')
            .addField('?recipe', 'Provides you with a minecraft recipe')
            .addField('?rick', 'Do it right or it will "nope" you. Stakes are high.')
            .setColor(0xff6363)
            .setTimestamp()
            .setFooter('PatBot pre-alpha v0.5 by accurates#0001 😎', 'https://i.imgur.com/tVsAOeR.png');
            message.channel.send(helpMenu);
        break;
        case 'insult':
            var insultList = ['kys', 'die', 'you look like shit', 'uninstall internet you are not worthy', 'consider game ending yourself', 'why do we still suffer having you around', 'heads-up, you are useless.', 'no one loves you.', 'stop using this command, even I hate you', 'you are not even worthy for an insult']
            const insult = new Discord.RichEmbed()
            .addField('Hey you', insultList[Math.floor(Math.random() * insultList.length)])
            .setColor(0xff6363)
            .setTimestamp()
            .setFooter('PatBot pre-alpha v0.5 by accurates#0001 😎', 'https://i.imgur.com/tVsAOeR.png');
            message.reply(insult);
        break;
        case 'status':
            if(args[1] === "help"){
                const statusHelpMenu = new Discord.RichEmbed()
                .setTitle('Status Help Menu')
                .addField('Correct usage', 'Use `?status` + the ip of the server you want,')
                .addField('Example:', '`?status play.xander.media`')
                .setColor(0xff6363)
                .setTimestamp()
                .setFooter('PatBot pre-alpha v0.5 by accurates#0001 😎', 'https://i.imgur.com/tVsAOeR.png');
            message.channel.send(statusHelpMenu);
            }
            else if(args[1] === undefined){
                const errorStatus = new Discord.RichEmbed()
                .setTitle('No Valid IP was entered')
                .addField('Correct usage', 'Use `?status` + the ip of the server you want,')
                .addField('Example:', '`?status play.xander.media`')
                .setColor(0xff6363)
                .setTimestamp()
                .setFooter('PatBot pre-alpha v0.5 by accurates#0001 😎', 'https://i.imgur.com/tVsAOeR.png');
            message.channel.send(errorStatus);
            }
            else if(args[1] !== "help"){
                var mcIP = args[1];
                var url = 'http://mcapi.us/server/status?ip=' + mcIP + '&port=' + mcPort;
                request(url, function(err, response, body) {
                    if(err) {
                        var statusReply = "Error retrieving server info";
                    }
                    body = JSON.parse(body);
                    var statusReply = '*Error: Minecraft server is either offline or the IP was invalid. For more info use ?status help*';
                    if(body.online) {
                        statusReply = '**Minecraft** server is **online**  -  ';
                        if(body.players.now) {
                            statusReply += '**' + body.players.now + '** people are playing!';
                        } else {
                            statusReply += '*Nobody is playing!*';
                        }
                    }
                    const statusCheck = new Discord.RichEmbed()
                    .setTitle('Server: ' + args[1])
                    .addField('Status: ', statusReply)
                    .setColor(0xff6363)
                    .setTimestamp()
                    .setFooter('PatBot pre-alpha v0.5 by accurates#0001 😎', 'https://i.imgur.com/tVsAOeR.png');
                    message.channel.send(statusCheck);
                    }); 
                }
        break;
        case 'bored':
            var funstuff = 'ok boomer';
            message.channel.send(funstuff)
        break;
        case 'recipe':
        if(args[1] === "anvil"){
            var recipeanvil = new Discord.RichEmbed()
            .setImage('https://www.digminecraft.com/decoration_recipes/images/make_anvil.png')
            .setColor(0xff6363)
            .setTimestamp()
            .setFooter('PatBot pre-alpha v0.5 by accurates#0001 😎', 'https://i.imgur.com/tVsAOeR.png'); 
            message.channel.send(recipeanvil);         
        }
        else if(args[1] === "repeater"){
            var reciperepeater = new Discord.RichEmbed()
            .setImage('https://i2.wp.com/esmepatterson.com/wp-content/uploads/2020/02/How-to-Make-a-Redstone-Repeater-in-Minecraft.png?fit=516%2C486&ssl=1')
            .setColor(0xff6363)
            .setTimestamp()
            .setFooter('PatBot pre-alpha v0.5 by accurates#0001 😎', 'https://i.imgur.com/tVsAOeR.png');
            message.channel.send(reciperepeater);         
        }
        else if (args[1] === "1.14"){
            var recipeFourteen = new Discord.RichEmbed()
            .setTitle('1.14 New recipe list')
            .setImage('https://i.redd.it/fujubgc1vf031.png')
            .setColor(0xff6363)
            .setTimestamp()
            .setFooter('PatBot pre-alpha v0.5 by accurates#0001 😎', 'https://i.imgur.com/tVsAOeR.png');
            message.channel.send(recipeFourteen);
        }
        else if (args[1] === "list"){
            var recipelist = new Discord.RichEmbed()
            .addField('Available recipes', 'loom, anvil, repeater, blast furnace, campfire, composter')
            .setColor(0xff6363)
            .setTimestamp()
            .setFooter('PatBot pre-alpha v0.5 by accurates#0001 😎', 'https://i.imgur.com/tVsAOeR.png');
            message.channel.send(recipelist);
        }
        else{
            var recipedh = new Discord.RichEmbed()
            .addField('No item specified', 'Use ?recipe `item`')
            .addField('Available recipes', '1.14, anvil, repeater')
            .setColor(0xff6363)
            .setTimestamp()
            .setFooter('PatBot pre-alpha v0.5 by accurates#0001 😎', 'https://i.imgur.com/tVsAOeR.png');
            message.channel.send(recipedh);
        }
        break;
        case 'rick':
            if(args[1] === 'white'){
                var whiteRick = new Discord.RichEmbed()        
                .addField('[Intro]', '*music*')
                .addField('[Verse 1]', "We're no strangers to love \n You know the rules and so do I \n A full commitment's what I'm thinking of \n You wouldn't get this from any other guy")
                .addField('[Pre-Chorus 1]', "I just wanna tell you how I'm feeling Gotta make you understand")
                .addField('[Chorus]', 'Never gonna give you up \n Never gonna let you down \n Never gonna run around and desert you \n Never gonna make you cry \n Never gonna say goodbye \n Never gonna tell a lie and hurt you')
                .addField('[Verse 2]', "We've known each other for so long \n Your heart's been aching but you're too shy to say it \n Inside we both know what's been going on \n We know the game and we're gonna play it")
                .addField('[Pre-Chorus 2]', "And if you ask me how I'm feeling \n Don't tell me you're too blind to see")
                .addField('[Chorus]', 'Never gonna give you up \n Never gonna let you down \n Never gonna run around and desert you \n Never gonna make you cry \n Never gonna say goodbye \n Never gonna tell a lie and hurt you')
                .addField('[Bridge]', "(Ooh give you up) \n (Ooh give you up) \n (Ooh) Never gonna give, never gonna give (give you up) \n (Ooh) Never gonna give, never gonna give (give you up)")     
                .addField('[Verse 2]', "We've known each other for so long \n Your heart's been aching but you're too shy to say it \n Inside we both know what's been going on \n We know the game and we're gonna play it")
                .addField('[Pre-Chorus 1]', "I just wanna tell you how I'm feeling \n Gotta make you understand")
                .addField('[Chorus]', "Never gonna give you up \n Never gonna let you down \n Never gonna run around and desert you \n Never gonna make you cry \n Never gonna say goodbye \n Never gonna tell a lie and hurt you \n Never gonna give you up \n Never gonna let you down \n Never gonna run around and desert you \n Never gonna make you cry \n Never gonna say goodbye \n Never gonna tell a lie and hurt you \n Never gonna give you up \n Never gonna let you down \n Never gonna run around and desert you \n Never gonna make you cry \n Never gonna say goodbye \n Never gonna tell a lie and hurt you")     
                .setColor(0xff6363)
                .setTimestamp()
                .setFooter('PatBot pre-alpha v0.5 by accurates#0001 😎', 'https://i.imgur.com/tVsAOeR.png');
                message.channel.send(whiteRick);
            }
            else if(args[1] === "green"){
                var greenRick = new Discord.RichEmbed()
                .addField('PICKLE RIIIIICK', "Omg pickle rick is so funny I was up really late on a school nite and my mom was asleep and I laughed so hard I peed my pants!!!! She woke up and said I was grounded and I said, 'I'm too smart for school I'm pickle rickkkkkkkk!!!' and then the next day she packed all her things and left without saying goodbye idc though moms are dumb anyway not anyways most people get that confuzed hahahaha 🥒")
                .setColor(0xff6363)
                .setTimestamp()
                .setFooter('PatBot pre-alpha v0.5 by accurates#0001 😎', 'https://i.imgur.com/tVsAOeR.png');
                message.channel.send(greenRick);
            }
            else{
                var negativeEmbed = new Discord.RichEmbed()
                .addField('Nope', 'You failed')
                .setColor(0xff6363)
                .setTimestamp()
                .setFooter('PatBot pre-alpha v0.5 by accurates#0001 😎', 'https://i.imgur.com/tVsAOeR.png');
                message.channel.send(negativeEmbed);
            }
        break;
    }
});

bot.login(token);